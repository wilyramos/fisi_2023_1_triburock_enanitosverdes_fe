import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class AdminPresupuestoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Aquí puedes agregar el código para manejar los componentes de tu diseño
        // Por ejemplo, puedes asignar clics a los botones o realizar otras operaciones.

        val buttonPagar = findViewById<Button>(R.id.button20)
        buttonPagar.setOnClickListener {
            // Lógica para el botón "PAGAR"
        }

        val buttonFacturasPendientes = findViewById<Button>(R.id.button17)
        buttonFacturasPendientes.setOnClickListener {
            // Lógica para el botón "Facturas pendientes"
        }

        val buttonAdministrarPresupuesto = findViewById<Button>(R.id.button18)
        buttonAdministrarPresupuesto.setOnClickListener {
            // Lógica para el botón "Administrar presupuesto"
        }

        val buttonInicio = findViewById<Button>(R.id.button19)
        buttonInicio.setOnClickListener {
            // Lógica para el botón "Inicio"
        }

        val buttonHistorialPagos = findViewById<Button>(R.id.button16)
        buttonHistorialPagos.setOnClickListener {
            // Lógica para el botón "Historial de pagos"
        }

        // Puedes continuar asignando clics o realizando otras operaciones con los demás componentes de tu diseño
    }
}
